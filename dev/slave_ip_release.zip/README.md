# Slave IP — 코드 읽기 가이드

이 패키지는 passive slave 통신 프로토콜 IP의 RTL 소스, 테스트벤치, 참조 문서를 담고 있다.
처음 코드를 접하는 독자가 **어떤 순서로** 읽으면 전체 구조를 가장 빠르게 파악할 수 있는지를 기준으로 정리했다.

---

## 1단계 — 레지스터 맵부터 읽는다

> `docs/12_slave_ip_register_map_ko.md`

PS(ARM)에서 이 IP를 어떻게 제어하는지 가장 먼저 이해해야 한다.
`CTRL`, `DIV`, `DATA_OUT0`~`DATA_OUT5`, `STATUS`, `EVENT`, `FAULT` 레지스터의 의미와 비트 배치를 여기서 파악한다.
나머지 코드는 결국 이 레지스터 값을 처리하는 회로다.

---

## 2단계 — 사용자 매뉴얼로 동작 흐름을 파악한다

> `docs/13_slave_ip_user_manual_ko.md`

레지스터를 어떤 순서로 써야 하고, sync 감지 이후 슬롯 응답까지 어떤 순서로 일이 일어나는지 설명한다.
코드를 읽기 전에 "무슨 일을 하는 회로인지"를 머릿속에 먼저 그려두면 RTL이 훨씬 빠르게 읽힌다.

---

## 3단계 — 모듈 인터페이스 문서로 전체 구조를 잡는다

> `docs/11_slave_ip_module_interfaces_ko.md`

모듈 트리와 각 모듈의 책임, 주요 신호 방향이 정리되어 있다.
이 문서를 옆에 펼쳐두고 RTL을 읽으면 각 wire가 어디서 와서 어디로 가는지 바로 보인다.

---

## 4단계 — RTL을 데이터 흐름 순서로 읽는다

모듈 계층은 아래와 같다. **위에서 아래로**, 신호 흐름 순서대로 읽는 것을 권장한다.

```
slave_axi_ip_top          ← AXI glue. slave_axi_lite_regs + slave_ip_top 연결만 담당
│
├── slave_axi_lite_regs   ← AXI-Lite 프로토콜 처리 및 PS-visible register file
│
└── slave_ip_top          ← 통신 코어 top. AXI와 무관
    │
    ├── slave_cfg_shadow        설정 섀도우. AXI raw 값을 안전 경계에서 commit
    │
    ├── slave_sync_detector     master serial 입력에서 sync edge 검출
    ├── slave_broadcast_rx      sync 이후 42-bit codeword 수신
    ├── slave_broadcast_decoder Hamming SECDED 디코딩, halt mask / guard ticks 추출
    │   └── slave_hamming_dec
    │
    ├── slave_timing_scheduler  sync 기준 tick counter, slot별 target tick 계산
    ├── slave_slot_sequencer    active slot 순회, TX command 발행
    │
    ├── slave_payload_table     slot id → 32-bit payload 선택 (slot 0~5: PS, 6~7: PL)
    ├── slave_frame_builder     payload → 50-bit response frame 조립
    │   └── slave_hamming_enc
    ├── slave_tx_serializer     50-bit frame을 bit period에 맞춰 MSB-first 직렬 송신
    │
    └── slave_status_event      STATUS / EVENT / FAULT / IRQ 집계
```

각 파일은 파일 상단 주석 블록이 책임을 한 문장으로 요약하고 있으므로, 처음엔 그것만 읽고 넘어가도 된다.

### 읽는 순서 (권장)

| 순서 | 파일 | 이유 |
|:---:|---|---|
| 1 | `rtl/slave_axi_ip_top.v` | 전체 그림이 보이는 얇은 glue. 파일이 짧다 |
| 2 | `rtl/slave_ip_top.v` | 코어 top. 모든 서브모듈 연결과 상위 제어 정책 |
| 3 | `rtl/slave_axi_lite_regs.v` | AXI 프로토콜 처리. 읽기 어려우면 건너뛰고 나중에 봐도 된다 |
| 4 | `rtl/slave_cfg_shadow.v` | 설정이 언제 코어에 반영되는지 이해 |
| 5 | `rtl/slave_sync_detector.v` → `slave_broadcast_rx.v` → `slave_broadcast_decoder.v` | 수신 경로 |
| 6 | `rtl/slave_timing_scheduler.v` → `slave_slot_sequencer.v` | 타이밍과 슬롯 순회 |
| 7 | `rtl/slave_payload_table.v` → `slave_frame_builder.v` → `slave_tx_serializer.v` | 송신 경로 |
| 8 | `rtl/slave_status_event.v` | 상태/이벤트/fault 집계 |
| 9 | `reuse/slave_hamming_enc.v`, `reuse/slave_hamming_dec.v` | Hamming [42,35] codec. 프로토콜 호환성의 핵심 |

---

## 5단계 — 테스트벤치로 동작을 확인한다

> `tb/` 폴더

| 파일 | 무엇을 확인하는가 |
|---|---|
| `tb_slave_axi_ip_top_smoke.v` | AXI write → sync → slot 0 응답 프레임 한 사이클 |
| `tb_slave_axi_ip_top_fullcase.v` | active slot mask 0x00~0xFF 전수, PL payload invalid, guard invalid |
| `tb_slave_cfg_regs_status.v` | AXI register read/write, STATUS/EVENT/FAULT W1C |
| `tb_slave_broadcast_rx_decoder.v` | 수신 경로 단독. 1-bit 에러 정정, 2-bit 에러 검출 |
| `tb_slave_tx_path.v` | 송신 경로 단독. frame 조립 및 직렬화 |
| `tb_slave_timing_scheduler.v` | slot target tick 계산 정확도 |
| `tb_legacy_master_slave_comm.v` | 레거시 master_top과 실제 통신 루프 |

smoke TB를 먼저 읽으면 "AXI 설정 → master 프레임 수신 → slave 응답"이라는 전체 흐름을 코드로 확인할 수 있다.

---

## 레거시 마스터 호환성 테스트

> `docs/18_legacy_master_compat_test_ko.md`

기존 master_top과의 프로토콜 호환성을 어떻게 검증하는지 설명한다.
`tb_legacy_master_slave_comm.v`를 읽을 때 함께 참조한다.

---

## V&V 항목 확인

> `docs/14_slave_ip_vv_test_plan_ko.md`

어떤 기능 항목이 어느 TB에서 검증되는지 매핑이 정리되어 있다.
코드를 수정한 뒤 영향 받는 TB를 찾을 때 사용한다.

---

## 파일 목록

```
rtl/
  slave_ip_top.v                  통신 코어 top (AXI 없음)
  slave_axi_ip_top.v              AXI glue top
  slave_axi_lite_regs.v
  slave_cfg_shadow.v
  slave_sync_detector.v
  slave_broadcast_rx.v
  slave_broadcast_decoder.v
  slave_timing_scheduler.v
  slave_slot_sequencer.v
  slave_payload_table.v
  slave_frame_builder.v
  slave_tx_serializer.v
  slave_status_event.v
  slave_axi_ip_legacy_wrapper.v   레거시 호환성 테스트용 래퍼

reuse/
  slave_hamming_enc.v             Hamming [42,35] 인코더 (master 호환)
  slave_hamming_dec.v             Hamming [42,35] SECDED 디코더

tb/
  tb_slave_axi_ip_top_smoke.v
  tb_slave_axi_ip_top_fullcase.v
  tb_slave_cfg_regs_status.v
  tb_slave_broadcast_rx_decoder.v
  tb_slave_tx_path.v
  tb_slave_timing_scheduler.v
  tb_legacy_master_slave_comm.v

docs/
  11_slave_ip_module_interfaces_ko.md
  12_slave_ip_register_map_ko.md
  13_slave_ip_user_manual_ko.md
  14_slave_ip_vv_test_plan_ko.md
  18_legacy_master_compat_test_ko.md
```
